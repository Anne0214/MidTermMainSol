# MidTermMainSol
期中主程式基底
